<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои заметки</title>
    <style>
        .completed {
            background-color: lightgreen; /* Подсветка зеленым цветом */
        }
    </style>
</head>
<body>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <h1>My Notes</h1>
    <form method="POST" action="/notes">
        <?php echo csrf_field(); ?>
        <p>Title</p>
        <input class="form-control" id="exampleInputPassword1" type="text" name="title" required>
        <p>Content</p>
        <textarea class="form-control" id="exampleInputPassword1" name="content" required></textarea><br><br>
        <button class="btn btn-primary" type="submit">Add Note</button><br><br>
    </form>
    <ul>
    <?php if(isset($notes) && $notes->isNotEmpty()): ?>
        <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="<?php echo e($note->is_completed ? 'completed' : ''); ?>">
                <form method="POST" action="/notes/<?php echo e($note->id); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input class="form-control" id="exampleInputPassword1" type="text" name="title" value="<?php echo e($note->title); ?>" required><br>
                    <textarea class="form-control" id="exampleInputPassword1" name="content" required><?php echo e($note->content); ?></textarea><br>
                    <button class="btn btn-primary" type="submit">Save Change</button><br><br>
                </form>
                <form method="POST" action="/notes/<?php echo e($note->id); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-primary" type="submit">Delete</button><br><br>
                </form>
                <form id="toggle-<?php echo e($note->id); ?>" method="POST" action="/notes/<?php echo e($note->id); ?>/complete" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <input type="hidden" name="is_completed" value="<?php echo e(!$note->is_completed); ?>">
                    <input  type="checkbox" <?php echo e($note->is_completed ? 'checked' : ''); ?> onchange="document.getElementById('toggle-<?php echo e($note->id); ?>').submit()">
                </form>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <li>No notes</li>
    <?php endif; ?>
    </ul>

    <form method="POST" action="/logout">
        <?php echo csrf_field(); ?>
        <button class="btn btn-primary" type="submit">Logout</button>
    </form>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</html>
<?php /**PATH C:\OSPanel\domains\borovinskikh\note\resources\views/index.blade.php ENDPATH**/ ?>