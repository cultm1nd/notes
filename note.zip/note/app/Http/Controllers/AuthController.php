<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class AuthController extends Controller
{
    public function showRegistrForm()
    {
        return view('registr');
    }

    public function registr(Request $request)
    {
      $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:5|confirmed',
      ]);
      User::create([
       'name'=>$request->name,
       'email'=>$request->email,
       'password'=>Hash::make($request->password),
      ]);
      
      return redirect('/login');
    }

    public function showLoginForm()
    {
        return view('login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'email'=>'required|string|email',
            'password'=>'required|string|min:3',
      ]);
      //проверки
      if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) 
      {
        return redirect('/notes');
      }

    return back()->withErrors(['email' => 'Неправильный email или пароль']);
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/login');
    }
}
