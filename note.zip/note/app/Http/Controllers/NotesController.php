<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Note;


class NotesController extends Controller
{
    public function index()
    {
        $notes = auth()->user()->notes;
        return view('index', compact('notes'));
    }

    public function store(Request $request)
    {
        // Валидация
        $request->validate([ 
            'title' => 'required', 
            'content' => 'required', 
        ]); 

        // Создание заметки для аутентифицированного пользователя
        auth()->user()->notes()->create($request->only(['title', 'content'])); 

        return redirect()->back(); 
    }

    public function update(Request $request, Note $note)
    {
        $request->validate([
            'title' => 'required',
            'content' => 'required',
        ]);
        $note->update($request->all());
        return redirect()->back();
    }

    public function destroy(Note $note)
    { 
     $note->delete();
     return redirect()->back();
    }

    
}
