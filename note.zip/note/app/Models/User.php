<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable; // Добавляем это
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable // Изменяем на Authenticatable
{
    use HasFactory, Notifiable; // Добавьте Notifiable, если вы планируете использовать уведомления

    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    public function notes() {
        return $this->hasMany(Note::class); // Обратите внимание на правильное имя класса
    }
}
